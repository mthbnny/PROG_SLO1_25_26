#ifndef testQ4_h
#define testQ4_h

const unsigned int Valeur_Brut_CptDS1820 = 0xFF33;
const float Multiple_Demi = 0.5;
const unsigned int Decalage_Bit = 1;

#endif

