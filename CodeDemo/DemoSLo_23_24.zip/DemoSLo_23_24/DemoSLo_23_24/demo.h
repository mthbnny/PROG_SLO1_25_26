#ifndef DEMO_H 
#define DEMO_H 

//-- énumération --// 
typedef enum {rouge, vert = 12, bleu, blanc, noir} e_couleur; 	 // e_couleur = type énum	
													 // rouge = 0; 
													 // bleu = 13 
													 
//-- définition --// 
#define MON_ENTIER	10
#define MILLE		1000
#define NB_CASE_TB 100






#endif






