#include <stdio.h>

void DispayStar(int a) {
    int i = 0;
    for (i = 0; i < a; i++) {
        printf("*");
    }
    printf("\n");
}