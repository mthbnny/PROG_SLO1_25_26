#ifndef MESFOCTION_h
#define MESFOCTION_h

void DispayStar(int a);


#endif
